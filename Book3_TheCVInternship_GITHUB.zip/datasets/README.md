# Datasets — The Computer Vision Internship

## Acquisition

All datasets must be downloaded separately (file sizes too large for GitHub).
Download scripts are provided in `datasets/download_scripts/`.

## Dataset summaries

### Oxford-IIIT Pets (Weeks 1-5)
37 cat and dog breeds, 7,349 images, CC BY 4.0.
Download: `python datasets/download_scripts/download_pets.py`

### NIH Chest X-Ray14 (Weeks 6, 10, 11)
112,120 de-identified chest X-rays, 14 pathology labels, CC0.
Download: `python datasets/download_scripts/download_cxr14.py`
Note: ~40GB. Allow overnight.

### BreakHis (Weeks 7, 10, 11)
7,909 breast cancer histopathology images, 8 tumour subtypes x 4 magnifications.
Download: Available from Kaggle (breakhis dataset) or the original Spanhol et al. repository.

### TCGA Uterine / TCGA-UCEC (Weeks 8, 10, 11)
Endometrial cancer whole-slide image patches, TCIA open access.
Requires TCIA registration at cancerimagingarchive.net.

### UCF-101 10-class subset (Week 9)
Video action recognition, 10 classes from UCF-101.
Download: `python datasets/download_scripts/download_ucf101.py`

### HAM10000 (Week 12)
10,015 dermoscopy images, 7 diagnostic classes, CC BY-NC 4.0.
Download from Kaggle: https://www.kaggle.com/datasets/kmader/skin-lesion-analysis-toward-melanoma-detection

## Folder structure

```
datasets/
  pets/          # Oxford-IIIT Pets
  xray/          # NIH Chest X-Ray14
  breakhis/      # BreakHis breast cancer
  tcga/          # TCGA uterine cancer patches
  ucf101/        # UCF-101 video clips
  ham10000/      # HAM10000 skin lesion
```
